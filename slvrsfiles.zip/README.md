# Vinlo — Prospects Télésec FR & Stratégie B2B

Fichiers de prospection et stratégie commerciale pour l'approche des entreprises françaises de télésecrétariat (partenariats offshore).

## Structure du dépôt

```
.
├── README.md
├── 01_entreprises_telesec_fr.csv   # Liste des 30 entreprises cibles
├── 02_decideurs_identifies.csv     # 12 décideurs identifiés
└── 03_strategie_b2b.csv            # Stratégie B2B détaillée
```

## Fichiers

### `01_entreprises_telesec_fr.csv`
30 entreprises françaises de télésecrétariat qualifiées comme prospects ou partenaires potentiels.

| Colonne | Description |
|---|---|
| `#` | Numéro de ligne |
| `Entreprise` | Nom de la société |
| `Année création` | Année de fondation |
| `Siège` | Ville siège social |
| `Département` | Département (code) |
| `Site web` | URL du site |
| `Email contact` | Email de contact identifié |
| `Téléphone` | Numéro de téléphone |
| `Taille / Volume` | Estimation de la taille ou du volume d'activité |
| `Type de relation` | Prospect, partenaire potentiel, concurrent… |
| `Angle d'attaque Vinlo` | Approche commerciale recommandée |
| `Note stratégique` | Commentaire de qualification |

### `02_decideurs_identifies.csv`
12 décideurs nominatifs avec informations de contact et pitch d'approche.

| Colonne | Description |
|---|---|
| `#` | Numéro de ligne |
| `Nom complet` | Prénom + Nom |
| `Fonction` | Titre / poste |
| `Entreprise` | Société de rattachement |
| `Localisation` | Ville ou région |
| `Source publique` | Source d'identification (LinkedIn, site, presse…) |
| `Canal recommandé` | Canal de prise de contact conseillé |
| `Pitch d'ouverture suggéré` | Script ou angle d'accroche recommandé |

### `03_strategie_b2b.csv`
Document de stratégie B2B structuré : constat marché, positionnement Vinlo, axes de partenariat offshore.

## Usage

Ces fichiers sont au format CSV encodé en UTF-8 (avec BOM pour compatibilité Excel).  
Ils peuvent être ouverts directement dans Excel, Google Sheets, ou traités avec pandas :

```python
import pandas as pd
df = pd.read_csv('01_entreprises_telesec_fr.csv', encoding='utf-8-sig')
```

## Confidentialité

⚠️ Ces données contiennent des informations commerciales sensibles (contacts, stratégie).  
Assurez-vous que le dépôt est **privé** avant de pousser ce contenu.
